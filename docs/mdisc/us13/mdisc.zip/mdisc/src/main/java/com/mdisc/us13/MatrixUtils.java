package com.mdisc.us13;

import java.util.List;
import java.util.Map;

public class MatrixUtils {

    public static int[][] computeWalksMatrix(int power, Map<String, List<Edge>> graph, List<String> stationOrder) {
        int size = stationOrder.size();
        int[][] adjacencyMatrix = new int[size][size];

        for (int i = 0; i < size; i++) {
            String station = stationOrder.get(i);
            for (Edge edge : graph.getOrDefault(station, List.of())) {
                int j = stationOrder.indexOf(edge.to);
                adjacencyMatrix[i][j] = 1;
            }
        }

        return matrixPower(adjacencyMatrix, power);
    }

    public static int[][] matrixPower(int[][] matrix, int power) {
        int size = matrix.length;
        int[][] result = new int[size][size];

        // Initialize result as the identity matrix
        for (int i = 0; i < size; i++) {
            result[i][i] = 1;
        }

        int[][] base = matrix;
        while (power > 0) {
            if ((power & 1) == 1) {
                result = multiplyMatrices(result, base);
            }
            base = multiplyMatrices(base, base);
            power >>= 1;
        }

        return result;
    }

    public static int[][] multiplyMatrices(int[][] a, int[][] b) {
        int size = a.length;
        int[][] result = new int[size][size];

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        return result;
    }

    public static boolean[][] computeTransitiveClosure(Map<String, List<Edge>> graph, List<String> stationOrder) {
        int size = stationOrder.size();
        boolean[][] closure = new boolean[size][size];

        // Initialize the closure matrix
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                closure[i][j] = (i == j); // Reflexive (self to self)
            }
        }

        // Add direct connections from the adjacency list
        for (int i = 0; i < size; i++) {
            String station = stationOrder.get(i);
            for (Edge edge : graph.getOrDefault(station, List.of())) {
                int j = stationOrder.indexOf(edge.to);
                if (j != -1) {
                    closure[i][j] = true;
                }
            }
        }

        // Apply Floyd-Warshall to compute transitive closure
        for (int k = 0; k < size; k++) {
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    closure[i][j] = closure[i][j] || (closure[i][k] && closure[k][j]);
                }
            }
        }

        return closure;
    }

    public static boolean isFullyConnected(boolean[][] closure) {
        int size = closure.length;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (!closure[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }

    public static void printMatrix(boolean[][] matrix) {
        for (boolean[] row : matrix) {
            for (boolean value : row) {
                System.out.print((value ? 1 : 0) + " ");
            }
            System.out.println();
        }
    }
}
