package com.mdisc.us13;

public class Station {
    private final String name;
    private final String type;

    public Station(String name) {
        this.name = name;
        if (name.startsWith("D_")) {
            this.type = "depot";
        } else if (name.startsWith("T_")) {
            this.type = "terminal";
        } else {
            this.type = "station";
        }
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }
}
