package com.mdisc.us13;

public class Station {
    private final String name;

    public Station(String name) {
        this.name = name;
    }

    public String getType() {
        // Determine the station type from the first letter of the name
        if (name.startsWith("D_")) return "depot";
        if (name.startsWith("S_")) return "station";
        if (name.startsWith("T_")) return "terminal";
        return "unknown";
    }

    @Override
    public String toString() {
        return name;
    }
}
