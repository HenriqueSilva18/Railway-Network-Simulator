package com.mdisc.us13;

public class Edge {
    String from;
    String to;
    boolean electrified;
    double distance;

    public Edge(String from, String to, boolean electrified, double distance) {
        this.from = from;
        this.to = to;
        this.electrified = electrified;
        this.distance = distance;
    }

    @Override
    public String toString() {
        return from + " -> " + to + " [" + (electrified ? "Electrified" : "Non-electrified") + ", " + distance + " km]";
    }
}
