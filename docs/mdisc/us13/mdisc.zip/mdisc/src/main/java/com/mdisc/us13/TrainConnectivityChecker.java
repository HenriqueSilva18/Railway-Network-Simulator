package com.mdisc.us13;
import java.io.*;
import java.util.*;

public class TrainConnectivityChecker {

    enum TrainType { STEAM, DIESEL, ELECTRIC }

    static Map<String, Station> stations = new HashMap<>();
    static Map<String, List<Edge>> graph = new HashMap<>();
    static List<String> stationOrder = new ArrayList<>();

    public static void loadCSV(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue; // Skip empty lines
            String[] parts = line.split(";");
            if (parts.length < 4) continue; // Skip malformed lines

            String from = parts[0].trim();
            String to = parts[1].trim();
            boolean electrified = parts[2].trim().equals("1");
            double distance = Double.parseDouble(parts[3].trim());

            stations.putIfAbsent(from, new Station(from));
            stations.putIfAbsent(to, new Station(to));

            if (!stationOrder.contains(from)) stationOrder.add(from);
            if (!stationOrder.contains(to)) stationOrder.add(to);

            graph.putIfAbsent(from, new ArrayList<>());
            graph.putIfAbsent(to, new ArrayList<>());
            graph.get(from).add(new Edge(from, to, electrified, distance));
            graph.get(to).add(new Edge(to, from, electrified, distance));
        }
    }

    public static boolean canTravel(String start, String end, TrainType trainType, String requiredStationType) {
        Set<String> visited = new HashSet<>();
        return dfs(start, end, trainType, requiredStationType, graph, stations, visited);
    }

    private static boolean dfs(String current, String end, TrainType trainType, String stationType, Map<String, List<Edge>> graph, Map<String, Station> stations, Set<String> visited) {
        if (current.equals(end)) return true;
        visited.add(current);

        for (Edge edge : graph.getOrDefault(current, new ArrayList<>())) {
            String neighbor = edge.to;
            if (!visited.contains(neighbor)) {
                boolean isElectricOK = !(trainType == TrainType.ELECTRIC && !edge.electrified);

                String neighborType = stations.get(neighbor).getType().toLowerCase();
                boolean isStationTypeOK =
                        stationType.equalsIgnoreCase("any") ||
                                stationType.equalsIgnoreCase(neighborType) ||
                                (stationType.equalsIgnoreCase("station+terminal") &&
                                        (neighborType.equals("station") || neighborType.equals("terminal")));

                if (isElectricOK && isStationTypeOK) {
                    if (dfs(neighbor, end, trainType, stationType, graph, stations, visited)) return true;
                }
            }
        }
        return false;
    }


    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        // Ask user for which CSV file to load
        System.out.println("Enter CSV file path (e.g., data/scenario1_lines.csv):");
        String filePath = sc.nextLine().trim();
        loadCSV(filePath);

        // Show available station list
        System.out.println("Available stations:");
        for (String s : stationOrder) {
            System.out.println(" - " + s);
        }

        System.out.println("\nEnter start station (or 'any'):");
        String start = sc.nextLine().trim();

        System.out.println("Enter end station (or 'any'):");
        String end = sc.nextLine().trim();

        System.out.println("Enter train type (STEAM, DIESEL, ELECTRIC):");
        TrainType trainType = TrainType.valueOf(sc.nextLine().trim().toUpperCase());

        System.out.println("Enter station type (depot, station, terminal, any):");
        String stationType = sc.nextLine().trim().toLowerCase();

        boolean anyResult = false;
        List<String> allStations = new ArrayList<>(stations.keySet());

        if (start.equalsIgnoreCase("any")) {
            for (String s : allStations) {
                if (canTravel(s, end, trainType, stationType)) {
                    System.out.println(" Train can travel from " + s + " to " + end);
                    anyResult = true;
                }
            }
            if (!anyResult) System.out.println(" No valid route found from any station to " + end);
        } else if (end.equalsIgnoreCase("any")) {
            for (String s : allStations) {
                if (canTravel(start, s, trainType, stationType)) {
                    System.out.println(" Train can travel from " + start + " to " + s);
                    anyResult = true;
                }
            }
            if (!anyResult) System.out.println(" No valid route found from " + start + " to any station");
        } else {
            anyResult = canTravel(start, end, trainType, stationType);
            System.out.println(anyResult ? " Train can travel!" : " No valid route found.");
        }

        // Show visual graph using GraphStream
        GraphVisualizer.showGraph(graph, stations);

        // Matrix walk length input   => Not Necessery
//        System.out.println("\nEnter path length to compute walk count (e.g., 4):");
//        int length = sc.nextInt();

//        int i = stationOrder.indexOf(start);
//        int j = stationOrder.indexOf(end);
//
//        if (i == -1 || j == -1) {
//            System.out.println("⚠️ One or both stations not found in matrix. Showing entire matrix:");
//            int[][] walks = MatrixUtils.computeWalksMatrix(length, graph, stationOrder);
//            MatrixUtils.printMatrix(walks);
//        } else {
//            int[][] walks = MatrixUtils.computeWalksMatrix(length, graph, stationOrder);
//            System.out.println("Number of walks of length " + length + " from " + start + " to " + end + ": " + walks[i][j]);
//            System.out.println("\nWalk count matrix M^" + length + ":");
//            MatrixUtils.printMatrix(walks);
//        }

    }
}
