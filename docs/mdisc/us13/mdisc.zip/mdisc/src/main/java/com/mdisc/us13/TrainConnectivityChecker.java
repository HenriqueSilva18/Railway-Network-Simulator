package com.mdisc.us13;

import java.io.*;
import java.util.*;

public class TrainConnectivityChecker {

    enum TrainType { STEAM, DIESEL, ELECTRIC }

    static Map<String, Station> stations = new HashMap<>();
    static Map<String, List<Edge>> graph = new HashMap<>();
    static List<String> stationOrder = new ArrayList<>();

    public static void loadCSV(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] parts = line.split(";");
            if (parts.length < 4) continue;

            String from = parts[0].trim().replaceAll("\\s+", "_");
            String to = parts[1].trim().replaceAll("\\s+", "_");
            boolean electrified = parts[2].trim().equals("1");
            double distance = Double.parseDouble(parts[3].trim());

            stations.putIfAbsent(from, new Station(from));
            stations.putIfAbsent(to, new Station(to));

            if (!stationOrder.contains(from)) stationOrder.add(from);
            if (!stationOrder.contains(to)) stationOrder.add(to);

            graph.putIfAbsent(from, new ArrayList<>());
            graph.putIfAbsent(to, new ArrayList<>());
            graph.get(from).add(new Edge(from, to, electrified, distance));
            graph.get(to).add(new Edge(to, from, electrified, distance));
        }
    }

    public static boolean canTravel(String start, String end, TrainType trainType, String stationType) {
        Set<String> visited = new HashSet<>();
        return dfs(start, end, trainType, stationType, visited);
    }

    private static boolean dfs(String current, String end, TrainType trainType, String stationType, Set<String> visited) {
        if (current.equals(end)) return true;
        visited.add(current);

        for (Edge edge : graph.getOrDefault(current, new ArrayList<>())) {
            String neighbor = edge.to;
            if (visited.contains(neighbor)) continue;

            boolean isElectricOK = !(trainType == TrainType.ELECTRIC && !edge.electrified);

            String neighborType = stations.get(neighbor).getType().toLowerCase();
            boolean isStationTypeOK = stationType.equals("any") || stationType.contains(neighborType);

            if (isElectricOK && isStationTypeOK) {
                if (dfs(neighbor, end, trainType, stationType, visited)) return true;
            }
        }
        return false;
    }

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter CSV file path (e.g., data/scenario1_lines.csv):");
        String filePath = sc.nextLine().trim();
        loadCSV(filePath);

        System.out.println("Available stations:");
        for (String s : stationOrder) {
            System.out.println(" - " + s);
        }

        System.out.println("\nEnter start station (or 'any'):");
        String start = sc.nextLine().trim();

        System.out.println("Enter end station (or 'any'):");
        String end = sc.nextLine().trim();

        System.out.println("Enter train type (STEAM, DIESEL, ELECTRIC):");
        TrainType trainType = TrainType.valueOf(sc.nextLine().trim().toUpperCase());

        System.out.println("Enter station types to include (e.g., station+terminal, depot+station):");
        String stationType = sc.nextLine().trim().toLowerCase();

        boolean anyResult = false;
        List<String> allStations = new ArrayList<>(stations.keySet());

        for (String s1 : allStations) {
            for (String s2 : allStations) {
                if (canTravel(s1, s2, trainType, stationType)) {
                    System.out.println("✅ Train can travel from " + s1 + " to " + s2);
                    anyResult = true;
                }
            }
        }
        if (!anyResult) System.out.println("❌ No valid route found.");

        GraphVisualizer.showGraph(graph, stations, stationType);

        System.out.println("\nEnter path length to compute walk count (e.g., 4):");
        int length = sc.nextInt();

        int[][] walks = MatrixUtils.computeWalksMatrix(length, graph, stationOrder);
        System.out.println("Number of walks of length " + length + ": " + walks.length);
        MatrixUtils.printMatrix(walks);

        boolean[][] closure = MatrixUtils.computeTransitiveClosure(graph, stationOrder);
        System.out.println("\nTransitive closure matrix:");
        MatrixUtils.printMatrix(closure);
        System.out.println("Transitive closure matrix verifies terminal connectivity.");
    }
}
