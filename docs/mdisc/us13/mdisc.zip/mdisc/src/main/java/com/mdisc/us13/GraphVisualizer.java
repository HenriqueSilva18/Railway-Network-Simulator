package com.mdisc.us13;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;

import java.util.*;

public class GraphVisualizer {

    public static void showGraph(Map<String, List<Edge>> graph, Map<String, Station> stations, String stationType) {
        // Ensure GraphStream uses Swing-based rendering
        System.setProperty("org.graphstream.ui", "swing");
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");

        Graph g = new SingleGraph("Railway Network");

        // Add nodes with appropriate color based on type
        for (String stationName : stations.keySet()) {
            String type = stations.get(stationName).getType().toLowerCase();

            // Adjust station type handling for "any" case
            if (!stationType.equals("any") && !stationType.contains(type)) continue;

            // Check if the node already exists to prevent duplication
            if (g.getNode(stationName) == null) {
                Node node = g.addNode(stationName);
                node.setAttribute("ui.label", stationName);

                String color = switch (type) {
                    case "depot" -> "red";
                    case "terminal" -> "green";
                    default -> "blue"; // station
                };
                node.setAttribute("ui.style", "fill-color: " + color + "; size: 10px;");
            }
        }

        // Add edges with electrified styling
        Set<String> addedEdges = new HashSet<>();
        for (Map.Entry<String, List<Edge>> entry : graph.entrySet()) {
            for (Edge edge : entry.getValue()) {
                String id1 = edge.from + "-" + edge.to;
                String id2 = edge.to + "-" + edge.from;
                if (!addedEdges.contains(id1) && !addedEdges.contains(id2)) {
                    // Check if both nodes exist before adding the edge
                    if (g.getNode(edge.from) != null && g.getNode(edge.to) != null) {
                        String label = (edge.electrified ? "⚡ " : "") + edge.distance + " km";
                        var e = g.addEdge(id1, edge.from, edge.to);
                        e.setAttribute("ui.label", label);
                        if (edge.electrified) {
                            e.setAttribute("ui.style", "fill-color: green; size: 2px;");
                        } else {
                            e.setAttribute("ui.style", "fill-color: gray; size: 1px;");
                        }
                        addedEdges.add(id1);
                    }
                }
            }
        }

        // Apply global style
        g.setAttribute("ui.stylesheet", """
            node {
                text-size: 14px;
                text-alignment: center;
                stroke-mode: plain;
                stroke-color: black;
            }
            edge {
                text-size: 12px;
                fill-color: gray;
                text-alignment: center;
            }
        """);

        try {
            g.display();
        } catch (Exception e) {
            System.err.println("⚠️ GraphStream failed to launch viewer: " + e.getMessage());
        }
    }
}
