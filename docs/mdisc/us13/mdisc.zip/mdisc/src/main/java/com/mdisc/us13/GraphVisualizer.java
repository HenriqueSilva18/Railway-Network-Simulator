package com.mdisc.us13;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;

import java.util.*;

public class GraphVisualizer {

    public static void showGraph(Map<String, List<Edge>> graph, Map<String, Station> stations) {
        // GraphStream setup
        System.setProperty("org.graphstream.ui", "swing");
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");

        Graph g = new SingleGraph("Railway Network");

        // Add nodes with appropriate color based on type
        for (String stationName : stations.keySet()) {
            Node node = g.addNode(stationName);
            node.setAttribute("ui.label", stationName);

            String type = stations.get(stationName).getType().toLowerCase();
            String color = switch (type) {
                case "depot" -> "red";
                case "terminal" -> "green";
                default -> "blue"; // station
            };
            node.setAttribute("ui.style", "fill-color: " + color + "; size: 10px;");
        }

        // Add edges with electrified styling
        Set<String> addedEdges = new HashSet<>();
        for (Map.Entry<String, List<Edge>> entry : graph.entrySet()) {
            for (Edge edge : entry.getValue()) {
                String id1 = edge.from + "-" + edge.to;
                String id2 = edge.to + "-" + edge.from;
                if (!addedEdges.contains(id1) && !addedEdges.contains(id2)) {
                    String label = (edge.electrified ? "⚡ " : "") + edge.distance + " km";
                    var e = g.addEdge(id1, edge.from, edge.to);
                    e.setAttribute("ui.label", label);
                    e.setAttribute("ui.style", edge.electrified ? "fill-color: green; size: 2px; text-size: 12px; text-alignment: center;" : "fill-color: gray; text-size: 12px; text-alignment: center;");
                    addedEdges.add(id1);
                }
            }
        }

        // Apply styling
        g.setAttribute("ui.stylesheet", """
            node {
                text-size: 14px;
                text-alignment: center;
                stroke-mode: plain;
                stroke-color: black;
            }
        """);

        try {
            g.display();
        } catch (Exception e) {
            System.err.println("⚠️ GraphStream failed to launch viewer: " + e.getMessage());
        }
    }
}
